//
//  ViewController.swift
//  Swift4MagicPush1
//
//  Created by Yuta Fujii on 2017/07/29.
//  Copyright © 2017年 Yuta Fujii. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet var nameTextField: UITextField!
    
    @IBOutlet var honbunTextField: UITextField!
    
    let timerNotificationIdentifier = "id1"
    
    var resultString = ""
    var ketugouString = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameTextField.delegate = self
        honbunTextField.delegate = self
    
    }

    func textFieldShouldReturn(_ textField: UITextField) -> 
        Bool {
    
            //名前と本文に記入された文字を繋げる
            resultString = nameTextField.text! + ketugouString + honbunTextField.text!
            
            //キーボードを閉じる
            textField.becomeFirstResponder()
            
            return true
        
    }
    
    
    func startPush(){
        
        //5秒後にプッシュ通知を飛ばす
        //通知飛ばしていいかの許可
        
        UNUserNotificationCenter.current().getNotificationSettings { (settings) in
            
            if(settings.authorizationStatus == .authorized){
                
                //知らせる
                self.push()
            }else{
                
                UNUserNotificationCenter.current().requestAuthorization(options: [.sound,.badge,.alert], completionHandler: { (granted, error) in
                    
                    if let error = error{
                        
                        print(error)
                    }else{
                        
                        if(granted){
                            
                            self.push()
                        }
                        
                    }
                    
                })
                
            }
            
        }
        
        
    }
    
    func push(){
        
        //テキストフィールドの中にある文字をセットする
        
        let content = UNMutableNotificationContent()
        content.title = nameTextField.text!
        content.subtitle = honbunTextField.text!
        
        let timerIconURL = Bundle.main.url(forResource: "sunrise", withExtension: "jpg")
        
        let attach = try! UNNotificationAttachment(identifier: timerNotificationIdentifier, url: timerIconURL!, options: nil)
        
        content.attachments.append(attach)
        
        //5秒後に送信する
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5.0, repeats: false)
        
        let notificationRequest = UNNotificationRequest(identifier: "", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(notificationRequest) { (error) in
            
            //エラー処理
            if let error = error{
                print(error)
            }else{
                
                print("配信されました！")
            }
            
        }
        
    }
    
    @IBAction func tap(_ sender: Any) {
   
        startPush()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

